    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('landing/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landing/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landing/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landing/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landing/lib/counterup/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landing/lib/parallax/parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landing/lib/lightbox/js/lightbox.min.js')); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('landing/js/main.js')); ?>"></script>

    <script>
        $('#hreflogout').on('click', function(){
            $('#logout').click();
        });
    </script>
<?php /**PATH C:\Users\LENOVO\Desktop\project-pakan\resources\views/Components/js.blade.php ENDPATH**/ ?>