<div class="container-fluid px-0" style="background-color: #07683B;">
    <div class="row g-0 d-none d-lg-flex">
        <div class="col-lg-6 ps-5 text-start">
            <div class="h-100 d-inline-flex align-items-center text-light">
                <span>Follow Us:</span>
                <a class="btn btn-link text-light" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-link text-light" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-link text-light" href=""><i class="fab fa-linkedin-in"></i></a>
                <a class="btn btn-link text-light" href=""><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div class="col-lg-6 text-end">
            <div class="h-100 d-inline-flex align-items-center text-dark py-2 px-4" style="background-color: #F26F21;">
                <span class="me-2 fw-semi-bold" style="color: white;"><i class="fa fa-phone-alt me-2"></i>Call Us:</span>
                <span style="color: white;">+62 899 8009 635</span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\LENOVO\Desktop\project-pakan\resources\views/Components/topbar.blade.php ENDPATH**/ ?>