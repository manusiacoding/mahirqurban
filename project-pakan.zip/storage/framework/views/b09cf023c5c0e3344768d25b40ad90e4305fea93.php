<?php $__env->startSection('content'); ?>
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="section-title bg-white text-center text-primary px-3">Our Products</p>
            <h1 class="mb-5">Our Dairy Products For Healthy Living</h1>
        </div>
        
        <div class="row gx-4">
            <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="product-item">
                    <div class="position-relative">
                        <img class="img-fluid" src="<?php echo e(asset('landing/img/product-1.jpg')); ?>" alt="">
                    </div>
                    <div class="text-center p-4">
                       <table class="table">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Customer Name</th>
                                    <th>Product</th>
                                    <th>Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e(Auth::user()->name); ?></td>
                                    <td><?php echo e($transaksi->customer_name); ?></td>
                                    <td><?php echo e($productIndo->name); ?></td>
                                    <td><?php echo e($transaksi->total_price); ?></td>
                                </tr>
                            </tbody>
                       </table>
                       <button id="pay-button" class="btn btn-primary">Pay!</button>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>

    // For example trigger on button clicked, or any time you need
    var payButton = document.getElementById('pay-button');
    payButton.addEventListener('click', function () {
      // Trigger snap popup. @TODO: Replace TRANSACTION_TOKEN_HERE with your transaction token

      window.snap.pay('<?php echo Session::get("snapToken"); ?>', {
        onSuccess: function(result){
          /* You may add your own implementation here */
          alert("payment success!"); console.log(result);
        },
        onPending: function(result){
          /* You may add your own implementation here */
          alert("wating your payment!"); console.log(result);
        },
        onError: function(result){
          /* You may add your own implementation here */
          alert("payment failed!"); console.log(result);
        },
        onClose: function(){
          /* You may add your own implementation here */
          alert('you closed the popup without finishing the payment');
        }
      })
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\project-pakan\resources\views/landing/indo/invoice.blade.php ENDPATH**/ ?>